package com.gsiam.poc;

public class PostalCodes {

	private PostalCode[] postalCodes;

//	public PostalCodes() {
//
//	}

	public PostalCode[] getPostalCodes() {
		return postalCodes;
	}

	public void setPostalCodes(PostalCode[] postalCodes) {
		this.postalCodes = postalCodes;
	}
}
