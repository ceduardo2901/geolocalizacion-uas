package com.gsiam.poc;

public class AircraftTypes {

	private AircraftType[] aircraftTypes;

	AircraftTypes() {

	}

	public AircraftType[] getAircraftTypes() {
		return aircraftTypes;
	}

	public void setAircraftTypes(AircraftType[] aircraftTypes) {
		this.aircraftTypes = aircraftTypes;
	}

	
}
